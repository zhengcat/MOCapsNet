import torch
import torch.nn.functional as F
import torch.nn as nn
from torch import relu
from torch.autograd import Variable
import torch.optim.adam
import torch.optim.sgd
from torch.nn import Parameter


def xavier_init(m):
    if type(m) == nn.Linear:
        nn.init.xavier_normal_(m.weight)
        if m.bias is not None:
            m.bias.data.fill_(0.0)

class LinearLayer(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.clf = nn.Sequential(nn.Linear(in_dim, out_dim))
        self.clf.apply(xavier_init)

    def forward(self, x):
        x = self.clf(x)
        return x

class FeaInfor(nn.Module):
    def __init__(self, in_dim):
        super().__init__()
        self.FeatureInforEncoder = LinearLayer(in_dim, in_dim)

    def forward(self, data_list):
        FeatureInfo = torch.sigmoid(self.FeatureInforEncoder(data_list))
        feature = data_list * FeatureInfo
        # feature = F.dropout(feature, self.dropout, training=self.training)
        return feature,FeatureInfo #特征置信度后的特征

class OmicInfor(nn.Module):
    def __init__(self,in_dim, hidden_dim,num_class):
        super().__init__()
        self.classes = num_class
        # self.dropout = dropout
        self.FeatureEncoder = LinearLayer(in_dim,hidden_dim) #特征降维
        self.OmicInforEncoder = LinearLayer(hidden_dim,1) #组学置信度
        self.Omicclass = LinearLayer(hidden_dim,num_class) #单组学分类

    def forward(self,data_list):
        feature = F.relu(self.FeatureEncoder(data_list))#降维
        # feature = F.dropout(feat_emb, self.dropout, training=self.training)
        Omiconfidence = self.OmicInforEncoder(feature)
        Omicfeature = feature * Omiconfidence
        TCPLogit = self.Omicclass(feature) #获得单组学的分类结果

        return Omiconfidence,Omicfeature,TCPLogit #组学置信度后的组学特征，置信度，单组学分类结果


class ConvCaps2D(nn.Module): #卷积到第一个胶囊层中
    def __init__(self):
        super(ConvCaps2D, self).__init__()
        self.capsules = nn.ModuleList([nn.Conv2d(in_channels=1, out_channels = primary_capslen,
                                                 kernel_size=(1,ks), stride=stride) for _ in range(filters)])#32个相同的东西

    def squash(self, tensor, dim=-1):
        norm = (tensor**2).sum(dim=dim, keepdim = True) # norm.size() is (None, 1152, 1)
        scale = norm / (1 + norm) # scale.size()  is (None, 1152, 1)
        return scale*tensor / torch.sqrt(norm)

    def forward(self, x):#x的行数，view相当于重reshape，
        outputs = [capsule(x).view(x.size(0), primary_capslen, -1) for capsule in self.capsules] # 32 list of (None, 1, 8, 36)
        outputs = torch.cat(outputs, dim = 2).permute(0, 2, 1)  # outputs.size() is (None, 1152, 8)
        return self.squash(outputs)

class Caps1D(nn.Module):#动态路由到表型胶囊层
    def __init__(self):
        super(Caps1D, self).__init__()
        self.num_iterations = num_iterations
        self.num_caps = 5# equals to class number
        self.num_routes= (int((neurons-ks)/stride)+1)*filters #输出的神经元大小
        # self.num_routes = (int((2603 - ks) / stride) + 1) * filters  # 输出的神经元大小
        self.in_channels=primary_capslen #输入的通道数量=4
        self.out_channels=digital_capslen#输出的通道数量=16维度

        self.W = nn.Parameter(torch.randn(self.num_caps,self.num_routes, self.in_channels, self.out_channels)) # class,weight,len_capsule,capsule_layer
#        self.W = nn.Parameter(torch.randn(3, 3136, 8, 32)) # num_caps, num_routes, in_channels, out_channels

           #nn.parameter是将这些参数变为可学习的参数
    def softmax(self, x, dim = 1):#也称为归一化函数
        transposed_input = x.transpose(dim, len(x.size()) - 1)
        softmaxed_output = F.softmax(transposed_input.contiguous().view(-1, transposed_input.size(-1)))#view(-1)是把张量展开成一维向量
        return softmaxed_output.view(*transposed_input.size()).transpose(dim, len(x.size()) - 1)

    def squash(self, tensor, dim=-1):#挤压操作
        norm = (tensor**2).sum(dim=dim, keepdim = True) # norm.size() is (None, 1152, 1)  **2代表平方
        scale = norm / (1 + norm)
        return scale*tensor / torch.sqrt(norm) #计算张量的平方根，单位化归一化过程

    # Routing algorithm  动态路由过程
    def forward(self, u):#u就是初级胶囊层uj|i

        u_ji = torch.matmul(u[:, None, :, None, :], self.W) # u_ji.size() is (None, 10, 1152, 1, 16)  张量的乘法matul
        b = Variable(torch.zeros(u_ji.size())) # b.size() is (None, 10, 1152, 1, 16)
        # b = b.to(device) # using gpu
        #Variable它是一种可以变化的变量,这正好就符合了反向传播,参数更新的属性
        for i in range(self.num_iterations):
            c = self.softmax(b, dim=2)#按照不同的dim规则来做归一化操作。2行相加
            v = self.squash((c * u_ji).sum(dim=2, keepdim=True)) # v.size() is (None, 10, 1, 1, 16)
            #c*u-ji=s，进行压缩，然后进行值的相加
            if i != self.num_iterations - 1:
                delta_b = (u_ji * v).sum(dim=-1, keepdim=True)
                b = b + delta_b

        v = v.squeeze() #这个函数的作用是去掉矩阵里维度为1的维度
        classes = (v ** 2).sum(dim=-1) ** 0.5
        classes = F.softmax(classes)

        return classes#第二层胶囊

class CapsNet(nn.Module): #整体模型调用函数模块
    def __init__(self):
#         super().__init__() #py3
        super(CapsNet, self).__init__() #py2
        self.fc1 = nn.Linear(1500,neurons)#全连接层,输入大小---输出大小
        self.dropout1 = nn.Dropout(p=dropout)
        self.primaryCaps = ConvCaps2D()#第一个胶囊层，包括32个胶囊
        self.digitCaps = Caps1D()#第二个表型层。

    def forward(self, x):
        x = torch.relu(self.fc1(x)) #act激活函数用的是relu
        x = self.primaryCaps(x)
        x = self.digitCaps(x)
        return x
neurons=150
primary_capslen=4
digital_capslen=16
ks=5
stride=2
# filters=32
filters=16
num_iterations=4
dropout=0.2
def margin_loss(labels, lengths, margin_plus, margin_minus, lambda_val):
    # Calculate the margin loss for multi-class classification
    num_classes = 2  # 五分类任务
    positive_loss = labels * torch.relu(margin_plus - lengths) ** 2
    negative_loss = (1 - labels) * torch.relu(lengths - margin_minus) ** 2

    loss = torch.sum(positive_loss + lambda_val * negative_loss)
    return loss

def margin_loss(labels, lengths, margin_plus, margin_minus, lambda_val):
    # Calculate the margin loss for multi-class classification
    num_classes = 5  # 五分类任务
    positive_loss = labels * torch.relu(margin_plus - lengths) ** 2
    negative_loss = (1 - labels) * torch.relu(lengths - margin_minus) ** 2

    loss = torch.sum(positive_loss + lambda_val * negative_loss)
    return loss

def init_model_dict(num_view,dim_list,hidden_dim,num_class):
    model_dict = {}
    for i in range(num_view):
        model_dict["FeaInfor{:}".format(i + 1)] =FeaInfor(dim_list[i])
        model_dict["OmicInfor{:}".format(i + 1)] = OmicInfor(dim_list[i], hidden_dim,num_class)
    if num_view >= 2:
        model_dict["CAPSULE"] = CapsNet()
    return model_dict


def init_optim(num_view, model_dict, lr_e, lr_c, reg):
    optim_dict = {}
    combined_parameters_fea = []
    combined_parameters_cap = []

    # 创建 FeaInfor 部分的优化器，并将参数添加到 combined_parameters_fea 中
    for i in range(num_view):
        fea_optimizer = torch.optim.Adam(model_dict['FeaInfor{:}'.format(i + 1)].parameters(), lr=lr_e, weight_decay=reg)
        omic_optimizer = torch.optim.Adam(model_dict['OmicInfor{:}'.format(i + 1)].parameters(), lr=lr_e, weight_decay=reg)
        optim_dict["FeaInfor{:}".format(i + 1)] = fea_optimizer
        optim_dict["OmicInfor{:}".format(i + 1)] = omic_optimizer
        combined_parameters_fea.extend(model_dict['FeaInfor{:}'.format(i + 1)].parameters())
        combined_parameters_fea.extend(model_dict['OmicInfor{:}'.format(i + 1)].parameters())

    # 创建 CAP 部分的优化器，并将参数添加到 combined_parameters_cap 中
    cap_optimizer = torch.optim.Adam(model_dict["CAPSULE"].parameters(), lr=lr_c, weight_decay=reg)
    optim_dict["CAP"] = cap_optimizer
    combined_parameters_cap.extend(model_dict["CAPSULE"].parameters())

    # 创建 Combined 优化器，用于一起训练 FeaInfor 和 CAP，但学习率可以不同
    combined_optimizer = torch.optim.Adam([
        {'params': combined_parameters_fea, 'lr': lr_e},
        {'params': combined_parameters_cap, 'lr': lr_c}
    ], weight_decay=reg)
    optim_dict["Combined"] = combined_optimizer

    return optim_dict

