import os
import pandas as pd
import numpy as np
import torch
import torch.nn.functional as F
from Utils_our import one_hot_tensor
from liner_model import init_model_dict, init_optim
from sklearn.metrics import accuracy_score, f1_score, recall_score
# from losses import contrastive_Loss,roc_auc_score

cuda = True if torch.cuda.is_available() else False

def prepare_trte_data(data_folder, view_list): #处理数据
    num_view = len(view_list)
    labels_tr = np.loadtxt(os.path.join(data_folder, "labels_tr.csv"), delimiter=',')
    labels_te = np.loadtxt(os.path.join(data_folder, "labels_te.csv"), delimiter=',')
    labels_tr = labels_tr.astype(int)
    labels_te = labels_te.astype(int)
    data_tr_list = []
    data_te_list = []
    for i in view_list: #加载视图数据
        data_tr_list.append(np.loadtxt(os.path.join(data_folder, str(i) + "_tr.csv"), delimiter=','))
        data_te_list.append(np.loadtxt(os.path.join(data_folder, str(i) + "_te.csv"), delimiter=','))
    num_tr = data_tr_list[0].shape[0]
    num_te = data_te_list[0].shape[0] #data_te_list[m],表示视图0 1 2，的行数0和列数1
    #获取tr-612和te-263的样本数量
    data_tr_tensor_list = []
    data_te_tensor_list = []
    for i in range(num_view): #转为浮点数
        data_tr_tensor_list.append(torch.FloatTensor(data_tr_list[i]))
        data_te_tensor_list.append(torch.FloatTensor(data_te_list[i]))
        if cuda:
            data_tr_tensor_list[i] = data_tr_tensor_list[i].cuda()
            data_te_tensor_list[i] = data_te_tensor_list[i].cuda()

    idx_dict = {}
    idx_dict["tr"] = list(range(num_tr))
    idx_dict["te"] = list(range(num_tr, (num_tr + num_te)))

    labels = np.concatenate((labels_tr, labels_te))

    return data_tr_tensor_list, data_te_tensor_list, idx_dict, labels


def train_epoch(data_tr_list, label, one_hot_label, model_dict, optim_dict,hidden_dim,num_class):
    loss_dict = {}
    class_weights = torch.tensor([1.0, 1.0, 2.0, 0.3, 1.0])

    # class_weights = torch.tensor([1.0,1.0])
    criterion = torch.nn.CrossEntropyLoss(weight=class_weights)
    for m in model_dict:
        model_dict[m].train()
    num_view = len(data_tr_list)
    z_list=[]
    w_list=[]
    for i in range(num_view):
        optim_dict["FeaInfor{:}".format(i + 1)].zero_grad()
        fea,w= model_dict["FeaInfor{:}".format(i + 1)](data_tr_list[i])#加权后特征，组学置信度
        w_list.append(w)
        fea_loss = torch.mean(w)
        optim_dict["OmicInfor{:}".format(i + 1)].zero_grad()
        Omiconfidence, Omicfeature, TCPLogit = model_dict["OmicInfor{:}".format(i+1)](fea)#获得组学置信度，特征与单组学的分类结果
        TCPLogit = TCPLogit.squeeze(1)
        Omiconfidence = Omiconfidence.squeeze(1)
        z_list.append(Omicfeature)
        pred = F.softmax(TCPLogit, dim=1)
        p_target = torch.gather(input=pred, dim=1, index=label.unsqueeze(dim=1)).view(-1)
        confidence_loss = torch.mean(criterion(TCPLogit, label) + F.mse_loss(Omiconfidence, p_target))#每个组学的分类结果，和组学置信度

    optim_dict["CAP"].zero_grad()
    new_data = torch.cat([z_list[0],z_list[1],z_list[2]] ,dim=1)
    cat_data = new_data.unsqueeze(1).unsqueeze(2)


    c = model_dict["CAPSULE"](cat_data)

    c_loss = torch.mean(criterion(c, label))
    # tol_loss = c_loss + fea_loss +  confidence_loss + 0.001 * loss_cil
    tol_loss = c_loss + fea_loss + confidence_loss
    tol_loss.backward()
    optim_dict["Combined"].step()
    loss_dict["Combined"] = tol_loss.detach().cpu().numpy().item()

    return  loss_dict


def test_epoch(data_list,  model_dict,hidden_dim,num_class):
    for m in model_dict:
        model_dict[m].eval()
    num_view = len(data_list)
    ci_list = []
    with torch.no_grad():  # 在测试阶段不需要计算梯度
        for i in range(num_view):
            # z, reconstructed_adj = model_dict["GAE{:}".format(i + 1)](data_list[i], adj_list[i])
            z, FeatureInfo = model_dict["FeaInfor{:}".format(i + 1)](data_list[i])
            Omiconfidence, Omicfeature, TCPLogit = model_dict["OmicInfor{:}".format(i + 1)](z)  # 获得组学置信度，特征与单组学的分类结果
            ci_list.append(Omicfeature)  # 保存测试数据的特征表示
    new_data = torch.cat([ci_list[0],ci_list[1],ci_list[2]],dim=1)
    cat_data = new_data.unsqueeze(1).unsqueeze(2)
    probs = model_dict["CAPSULE"](cat_data)
    return probs

def train_test(data_folder, view_list, num_class,
            lr_e, lr_c, num_epoch,reg,hidden_dim):  #预训练
    num_view = len(view_list)
    print(num_view)

    data_tr_list, data_te_list, trte_idx, labels_trte = prepare_trte_data(data_folder, view_list)
    labels_tr_tensor = torch.LongTensor(labels_trte[trte_idx["tr"]])#根据训练集索引，选择标签
    onehot_labels_tr_tensor = one_hot_tensor(labels_tr_tensor, num_class)
    dim_list = [x.shape[1] for x in data_tr_list]#初始特征维度大小
    model_dict = init_model_dict(num_view, dim_list,hidden_dim,num_class)

    print("\nTraining...")  # 模型的训练
    optim_dict = init_optim(num_view, model_dict, lr_e, lr_c,reg)
    for epoch in range(num_epoch + 1):
        train_loss = train_epoch(data_tr_list,labels_tr_tensor,onehot_labels_tr_tensor, model_dict, optim_dict,hidden_dim,num_class)
        print(f"Epoch {epoch}: Train Loss: {train_loss}")
        if epoch % 2 == 0:
            te_prob = test_epoch(data_te_list, model_dict,hidden_dim,num_class)
            te_prob_numpy = te_prob.detach().numpy()

            print("\nTest: Epoch {:d}".format(epoch))
            # print(te_prob_numpy.argmax(1))
            print("Test ACC: {:.4f}".format(accuracy_score(labels_trte[trte_idx["te"]], te_prob_numpy.argmax(1))))
            print("Test F1 weighted: {:.4f}".format(
                f1_score(labels_trte[trte_idx["te"]], te_prob_numpy.argmax(1), average='weighted')))
            print("Test F1 macro: {:.4f}".format(
                f1_score(labels_trte[trte_idx["te"]], te_prob_numpy.argmax(1), average='micro')))
            # print("Test AUC:{:.4f}".format(
            #     roc_auc_score(labels_trte[trte_idx["te"]], te_prob_numpy[:,1])))

