from train_linear_model import train_test

if __name__ == "__main__":

    data_folder = './BRCA'
    # data_folder = './LGG'
    view_list = [1,2,3]
    # view_list = [1, 2]
    num_epoch = 500

    if data_folder == './BRCA':
    # if data_folder == './ROSMAP':

        num_class = 5
        lr_e = 0.0001
        lr_c = 0.001
        reg = 1e-4
        hidden_dim = 500


    train_test(data_folder, view_list, num_class,lr_e, lr_c, num_epoch,reg,hidden_dim)
